﻿using CKK.Logic.Models;
using CKK.Logic.Repository.Implementation;
using CKK.Logic.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CKK.Online.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _products;
        private readonly IShoppingCartItemRepository _items;

        public ProductController(IProductRepository products, IShoppingCartItemRepository items)
        {
            _products = products;
            _items = items;
        }

        // GET: ProductController
        public ActionResult Index()
        {
            var productList = _products.GetAll().ToList();
            return View(productList);
        }

        // GET: ProductController/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var product = _products.Find(id ?? 0);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // POST: ProductController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Add(IFormCollection collection)
        {
            try
            {
                var id = Convert.ToInt32(collection["id"]);
                var quantity = Convert.ToInt32(collection["cartCount"]);
                var shoppingCartItem = new ShoppingCartItem
                { 
                    CustomerId = 1,
                    ProductId = id,
                    Quantity = quantity
                };
                _items.Add(shoppingCartItem);
                return RedirectToAction(nameof(Cart));
            }
            catch(Exception ex)
            {
                return View();
            }
        }

        public ActionResult Cart()
        {
            return View();
        }
    }
}
